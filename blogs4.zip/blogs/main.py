import datetime

from data import db_session
from data.jobs import Jobs
from data.users import User
from data.categories import Category
from flask import Flask, render_template, redirect, request, make_response, session
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from flask_restful import Api
# from sqlalchemy import or_
from flask_wtf import FlaskForm
from sqlalchemy import or_
from wtforms import StringField, PasswordField, BooleanField, SubmitField, TextAreaField
from wtforms.fields.html5 import EmailField
from wtforms.validators import DataRequired

app = Flask(__name__)
api = Api(app)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(days=365)
login_manager = LoginManager()
login_manager.init_app(app)


class RegisterForm(FlaskForm):
    name = StringField('Имя', validators=[DataRequired()])
    surname = StringField('Фамилия', validators=[DataRequired()])
    age = StringField('Возраст', validators=[DataRequired()])
    position = StringField('Должность', validators=[DataRequired()])
    speciality = StringField('Профессия', validators=[DataRequired()])
    address = StringField('Адрес', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    password_again = PasswordField('Повторите пароль', validators=[DataRequired()])
    email = EmailField('Почта', validators=[DataRequired()])
    submit = SubmitField('Войти')


class LoginForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


class NewsForm(FlaskForm):
    title = StringField('Заголовок', validators=[DataRequired()])
    content = TextAreaField("Содержание")
    is_private = BooleanField("Личное")
    submit = SubmitField('Применить')


class AutoAnswerForm(FlaskForm):
    title = ''
    surname = ''
    name = ''
    education = ''
    profession = ''
    sex = ''
    motivation = ''
    ready = ''


class JobForm(FlaskForm):
    title = StringField('Job Title', validators=[DataRequired()])
    teamleader = StringField('Team Leader id', validators=[DataRequired()])
    work_size = StringField('Work Size', validators=[DataRequired()])
    collaborators = StringField('collaborators', validators=[DataRequired()])
    is_finished = BooleanField("Is job finished?")
    category = StringField('Category id', validators=[DataRequired()])
    submit = SubmitField('submit')


class DepartmentForm(FlaskForm):
    title = StringField('Job Title', validators=[DataRequired()])
    chief = StringField('Chief name', validators=[DataRequired()])
    members = StringField('Members', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired()])
    submit = SubmitField('submit')


@login_manager.user_loader
def load_user(user_id):
    session = db_session.create_session()
    return session.query(User).get(user_id)


'''@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found'}), 404)
'''


@app.route('/lesson')
def get_lesson():
    form = NewsForm()
    return render_template('register.html', title='Регистрация',
                           form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        session = db_session.create_session()
        user = session.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/answer', methods=['GET', 'POST'])
@app.route('/auto_answer', methods=['GET', 'POST'])
def auto_answer():
    session = db_session.create_session()
    user = session.query(User).all()[-1]
    form = AutoAnswerForm()
    form.name = user.name
    form.surname = user.surname
    form.profession = user.speciality
    if form.validate_on_submit():
        return redirect('/login')
    return render_template('auto_answer.html', form=form)


@app.route('/job_add', methods=['GET', 'POST'])
def job_add():
    form = JobForm()
    session = db_session.create_session()
    if form.validate_on_submit():
        job = Jobs(job=form.title.data,
                   team_leader=form.teamleader.data,
                   work_size=form.work_size.data,
                   collaborators=form.collaborators.data,
                   is_finished=form.is_finished.data,
                   who_made=current_user.id,
                   category=form.category.data)
        session.add(job)
        session.commit()
        return redirect('/')
    return render_template('add_job.html', form=form)


@app.route('/list_prof/<list>')
def list_prof(list):
    lst = ['инженер-исследователь',
           'пилот',
           'строитель',
           "экзобиолог",
           'врач',
           'инженер по терраформированию',
           'климатолог',
           'специалист по радиационной защите',
           'астрогеолог',
           'гляциолог',
           'инженер жизнеобеспечения',
           'метеоролог',
           'оператор марсохода',
           'киберинженер',
           'штурман',
           'пилот дронов'
           ]
    if list == 'ol':
        return render_template('list_ol.html', list=lst)
    else:
        return render_template('list_ul.html', list=lst)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        session = db_session.create_session()
        if session.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            surname=form.surname.data,
            age=form.age.data,
            position=form.position.data,
            speciality=form.speciality.data,
            address=form.address.data,
            email=form.email.data
        )
        user.set_password(form.password.data)
        session.add(user)
        session.commit()
        return redirect('/auto_answer')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/')
def index():
    session = db_session.create_session()
    users = session.query(User).all()
    jobs = session.query(Jobs).all()
    names = {name.id: (name.name, name.surname) for name in users}
    return render_template('index.html', jobs=jobs, names=names)


@app.route('/job_delete/<job_id>', methods=['GET', 'POST'])
def job_delete(job_id):
    session = db_session.create_session()
    job = session.query(Jobs).filter(Jobs.id == job_id,
                                     or_(Jobs.who_made == current_user.id,
                                         current_user.id == 1)).first()
    if job:
        session.delete(job)
        session.commit()
        return redirect('/')
    else:
        return redirect('/')


@app.route('/job_edit/<job_id>', methods=['GET', 'POST'])
def job_edit(job_id):
    form = JobForm()
    session = db_session.create_session()
    job = session.query(Jobs).filter(Jobs.id == job_id, or_(
        Jobs.who_made == current_user.id, current_user.id == 1)).first()
    if form.validate_on_submit():
        if job:
            job.job = form.title.data
            job.team_leader = form.teamleader.data
            job.work_size = form.work_size.data
            job.collaborators = form.collaborators.data
            job.is_finished = form.is_finished.data
            job.category = form.category.data
            session.commit()
            return redirect('/')
    return render_template('edit_job.html', title='Редактирование новости', form=form, job=job)


@app.route('/add_department', methods=['GET', 'POST'])
def add_department():
    form = DepartmentForm()
    session = db_session.create_session()
    if form.validate_on_submit():
        department = Category(name=form.title.data,
                              chief=form.chief.data,
                              members=form.members.data,
                              email=form.email.data,
                              user=current_user.id)
        session.add(department)
        session.commit()
        return redirect('/departments')
    return render_template('add_department.html', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/departments')
def departments():
    session = db_session.create_session()
    users = session.query(User).all()
    departments = session.query(Category).all()
    names = {name.id: (name.name, name.surname) for name in users}
    return render_template('departments.html', departments=departments, names=names)


@app.route('/department_delete/<department_id>', methods=['GET', 'POST'])
def department_delete(department_id):
    session = db_session.create_session()
    dep = session.query(Category).filter(Category.id == department_id,
                                         or_(Category.user == current_user.id,
                                             current_user.id == 1)).first()
    if dep:
        session.delete(dep)
        session.commit()
        return redirect('/departments')
    else:
        return redirect('/departments')


@app.route('/department_edit/<department_id>', methods=['GET', 'POST'])
def department_edit(department_id):
    form = DepartmentForm()
    session = db_session.create_session()
    dep = session.query(Category).filter(Category.id == department_id, or_(
        Category.user == current_user.id, current_user.id == 1)).first()
    if form.validate_on_submit():
        if dep:
            dep.name = form.title.data
            dep.chief = form.chief.data
            dep.members = form.members.data
            dep.email = form.email.data
            session.commit()
            return redirect('/departments')
    return render_template('edit_department.html', title='Редактирование новости', form=form, dep=dep)


@app.route("/cookie_test")
def cookie_test():
    visits_count = int(request.cookies.get("visits_count", 0))
    if visits_count:
        res = make_response(f"Вы пришли на эту страницу {visits_count + 1} раз")
        res.set_cookie("visits_count", str(visits_count + 1),
                       max_age=60 * 60 * 24 * 365 * 2)
    else:
        res = make_response(
            "Вы пришли на эту страницу в первый раз за последние 2 года")
        res.set_cookie("visits_count", '1',
                       max_age=60 * 60 * 24 * 365 * 2)
    return res


@app.route('/session_test/')
def session_test():
    if 'visits_count' in session:
        session['visits_count'] = session.get('visits_count') + 1
        res = make_response(f"Вы пришли на эту страницу {session['visits_count']} раз")
    else:
        session.permanent = True
        session['visits_count'] = 1
        res = make_response(
            "Вы пришли на эту страницу в первый раз за последние 2 года")
    return res


def main():
    db_session.global_init("db/blogs.sqlite")
    app.run(debug=True)


if __name__ == '__main__':
    main()
